function main() {

    var towns = ['Москва', 'Амстердам'];

    console.log(towns[0]);

}

window.onload = main;